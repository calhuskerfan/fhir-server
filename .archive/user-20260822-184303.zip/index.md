# Local workflow index

This file is the entry point for fork-local working artifacts.

## Core context

- [README.md](README.md)
- [FileAudit.md](FileAudit.md)
- [context/repo-context.md](context/repo-context.md)
- [norms/workflow.md](norms/workflow.md)
- [norms/validation.md](norms/validation.md)

## Current work

### Tasks

- [tasks/T-0001.md](tasks/T-0001.md)
- [tasks/T-0002.md](tasks/T-0002.md)

### Plans

- [plans/P-0001/P-0001.md](plans/P-0001/P-0001.md)
- [plans/P-0002/P-0002.md](plans/P-0002/P-0002.md)
- [plans/P-0003/P-0003.md](plans/P-0003/P-0003.md)

### Current Status

- MongoDB sorting validation, BSON sort generation, and search-pipeline integration are complete.
- The final remaining step is a MongoDB-backed regression covering real ordering, filtering, and pagination.
- Focused and full MongoDB unit tests pass; shared parser-test execution is blocked by an unrelated `AddMongoDb` compile error in `src/Microsoft.Health.Fhir.Shared.Web/Startup.cs`.

### MongoDB Sorting Work

- [plans/P-0002/P-0002.md](plans/P-0002/P-0002.md)
- [src/Microsoft.Health.Fhir.MongoDb/Features/Search/MongoDbSortingValidator.cs](../src/Microsoft.Health.Fhir.MongoDb/Features/Search/MongoDbSortingValidator.cs)
- [src/Microsoft.Health.Fhir.MongoDb/Features/Search/Queries/QueryBuilderHelper.cs](../src/Microsoft.Health.Fhir.MongoDb/Features/Search/Queries/QueryBuilderHelper.cs)
- [src/Microsoft.Health.Fhir.MongoDb.UnitTests/Features/Search/MongoDbSortingValidatorTests.cs](../src/Microsoft.Health.Fhir.MongoDb.UnitTests/Features/Search/MongoDbSortingValidatorTests.cs)
- [src/Microsoft.Health.Fhir.MongoDb.UnitTests/Features/Search/Queries/QueryBuilderHelperSortingTests.cs](../src/Microsoft.Health.Fhir.MongoDb.UnitTests/Features/Search/Queries/QueryBuilderHelperSortingTests.cs)

## Validation artifacts

- [rest/lastupdated-search.rest](rest/lastupdated-search.rest)
- [rest/README.md](rest/README.md)
- [rest/fhir-smoke.rest](rest/fhir-smoke.rest)
- [rest/httpyac.config.json](rest/httpyac.config.json)
- [rest/patient.rest](rest/patient.rest)
- [rest/data/](rest/data/)

## Templates

- [templates/task-template.md](templates/task-template.md)
- [templates/plan-template.md](templates/plan-template.md)

## Notes

- This folder is intentionally kept outside the upstream repository instruction files.
- Use it as the local documentation and execution surface for agent-assisted work in this fork.
