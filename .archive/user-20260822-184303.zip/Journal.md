# Journal

## Running Work Log

Keep updates in here to aid in context switching and prompts for where to pick up.

### 2025-11-25

Compartment search rewriter was changed from a public to an abstract :(
https://github.com/calhuskerfan/fhir-server/commit/02ebc1bd4c4b19a6742779e2855a911e67ee6939

### 2025-04-14

Updating here a little bit, moving forward, just not as fast as I would like.


### 2024-11-24

1. Merged main into topic


## 2026-08-10

Started using some copilot chat to update implementation

## 2026-08-11
BUG: Can delete resource multiple times.
BUG: Not all records marked deleted.  is latest, but is deleted.

## 2026-08-16
Install httpyac globally `npm install -g httpyac`