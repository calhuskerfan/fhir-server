# Plan-####: <Plan title>

## Goal

Describe the overall objective, problem space, or product gap this plan addresses.

## Scope

- In scope:
  - <item 1>
  - <item 2>
- Out of scope:
  - <item 1>
  - <item 2>

## Why this matters

Explain the technical or product reason the work matters and any constraints that shaped the approach.

## Phases

### Phase 1: Investigate and confirm

- identify the root cause or requirement
- review the relevant implementation and references
- document any assumptions or risks

### Phase 2: Implement the focused fix

- make the minimal code or configuration change
- keep the solution aligned with the repository patterns and FHIR semantics

### Phase 3: Validate and document

- run the relevant targeted tests
- capture REST or integration checks if needed
- record evidence and any follow-up work

## Risks and open questions

- <risk or dependency>
- <open question>
- <follow-up item>

## Validation strategy

- target command: <example: dotnet test ... --filter ...>
- integration checks: <example: .user/rest/lastupdated-search.rest>
- pass criteria: <what counts as success>

## Deferred work

- <future issue or related cleanup that is intentionally not included in this plan>
