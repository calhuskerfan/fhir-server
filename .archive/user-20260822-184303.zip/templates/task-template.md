---
applyTo: "<path/to/area>"
description: "<short description of the task and its validation target>"
---

# Task-####: <Concise task title>

## Role and Objective

You are an expert software engineer working in this repository. Your goal is to complete the scoped work described here with clear validation and minimal drift from the original problem.

## Entry Point

- [<primary file or folder>](<relative/path>)
- [<secondary file or folder>](<relative/path>)

## References

- <spec, issue, previous task, or implementation reference>
- <comparison implementation if relevant>
- <related test or REST validation file>

## Implementation Steps

- [ ] Step 1: Define the root cause or requirement.
- [ ] Step 2: Implement the smallest fix or feature change.
- [ ] Step 3: Add or update focused tests.
- [ ] Step 4: Validate the behavior with the narrowest relevant command.
- [ ] Step 5: Capture any follow-up items or deferred work.

## Success Criteria

- [ ] The bug or feature gap is resolved at the required layer.
- [ ] Validation evidence is captured from a real command or test run.
- [ ] No unrelated work was introduced.
- [ ] Follow-up notes are recorded if broader issues remain.

## Notes

- Keep this task scoped.
- Prefer root-cause validation over speculative change.
- If this reveals a larger issue, document it but avoid broadening the task without direction.
