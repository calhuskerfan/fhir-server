# Repository context

This repository is the Microsoft FHIR Server, an open-source, standards-based FHIR implementation built on .NET.

## Primary purpose

- host FHIR resource APIs that follow HL7 FHIR behavior
- support versioned FHIR implementations such as STU3, R4, and R5
- support multiple persistence backends
- provide a server that can be validated with unit tests and REST requests

## Fork-specific focus

This fork is focused on validating and extending MongoDB-backed support for the server. The work here is intentionally targeted at the storage and search behaviors in the MongoDB implementation.

## Key repo areas

- src/Microsoft.Health.Fhir.MongoDb/ — MongoDB storage and query behavior
- src/Microsoft.Health.Fhir.Core/ — core FHIR logic and abstractions
- src/Microsoft.Health.Fhir.Api/ — REST API surface
- src/Microsoft.Health.Fhir.CosmosDb/ — comparison implementation for query builder semantics
- src/Microsoft.Health.Fhir.MongoDb.UnitTests/ — targeted MongoDB validation
- .user/ — local fork workflow artifacts, task tracking, and testing notes

## Working assumptions

- Prefer small, root-cause-driven changes.
- Keep FHIR semantics aligned with the specification and reference implementations.
- Validate the smallest relevant test surface first.
- Keep task and plan files in .user so the fork remains self-documenting without affecting upstream repo policy.

## Non-goals for this local workflow

- editing shared repo instruction files
- broad repo-wide cleanup unrelated to the current task
- adding UI or unrelated product work to a focused feature task
