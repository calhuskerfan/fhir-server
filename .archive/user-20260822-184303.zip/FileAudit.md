# File Audit

This file is the fork-local record of repository changes that are relevant to the MongoDB work. It is intended to help an agent understand what was changed in the shared repo, which items are likely transient, and which items still need review.

## Audit Summary

- Purpose: track shared-file changes made in this fork
- Scope: MongoDB integration and related startup/runtime adjustments
- Maintenance goal: keep the audit easy to review by automation or future agents

## Changed Files

| File | Why it changed | Review status | Notes |
|------|----------------|--------------|-------|
| .gitignore | Ignore local user/workflow artifacts | reviewed | transient; local-only files should stay out of source control |
| Directory.Packages.Props | Add MongoDB driver package(s) | reviewed | part of MongoDB dependency setup |
| Microsoft.Health.Fhir.sln | Include MongoDB and MongoDB unit test projects | reviewed | expected baseline extension for the fork |
| R4.slnf | Include MongoDB and MongoDB unit test projects in the R4 solution filter | reviewed | expected supporting change |
| src/Microsoft.Health.Fhir.Core/Features/KnownDataStores.cs | Register MongoDB as a supported datastore | reviewed | follows same pattern as CosmosDB and SQL Server |
| src/Microsoft.Health.Fhir.Core/Properties/AssemblyInfo.cs | Expose internals to MongoDB assembly | reviewed | required for internal access |
| src/Microsoft.Helath.Fhir.R4.Web/Microsoft.Helath.Fhir.R4.Web.csproj | Add MongoDB project reference | reviewed | expected project wiring |
| src/Microsoft.Helath.Fhir.R4.Web/Properties/launchsettings.json | Add SqlServerContainer and MongoDb launch profiles | reviewed | useful for local run scenarios |
| src/Microsoft.Health.Fhir.Shared.Web/appsettings.Development.json | Adjust logging levels | reviewed | likely transient, not core to MongoDB behavior |
| src/Microsoft.Health.Fhir.Shared.Web/Program.cs | Add environment variable loading | reviewed | may be a workaround for local config issues |
| src/Microsoft.Health.Fhir.Shared.Web/Startup.cs | Update datastore/runtime configuration registration | reviewed | aligns with CosmosDB and SQL Server startup patterns |

## Added / Modified in Shared Assembly Components

| File | Why it changed | Review status | Notes |
|------|----------------|--------------|-------|
| src/Microsoft.Health.Fhir.Core/Registration/MongoDbRuntimeConfiguration.cs | Add MongoDB runtime configuration support | needs review | uncertain whether this is in the proper assembly or registration location |

## Known Follow-up Items

| Item | Why it matters | Status |
|------|----------------|--------|
| build/docker/Dockerfile | Need to ensure copied artifacts include any MongoDB-related runtime changes | pending |
| Program.cs env-var workaround | Confirm this is intentional and not masking a config issue | pending |
| MongoDbRuntimeConfiguration placement | Verify the registration belongs in the intended component boundary | pending |
| appsettings.Development.json logging tweaks | Confirm whether any of these should remain in the fork or be reverted | pending |

## Agent Guidance

When working from this audit, treat the following as the default interpretation:

- entries marked "reviewed" are likely intentional and part of the MongoDB fork baseline
- entries marked "needs review" or "pending" are likely to require confirmation before merging or extending
- transient local-only items should not be treated as permanent repo changes
- this file is meant to support reasoning about the fork, not to replace code-level review

## Suggested Next Review Priorities

1. Validate the registration location for MongoDbRuntimeConfiguration.
2. Confirm whether the environment-variable bootstrap in Program.cs is required for all environments.
3. Check whether Docker build paths need MongoDB-related file copy updates.
4. Review any "transient" config changes for cleanup before upstream sharing.