# Local REST tests

REST requests for local development live together in this folder. Mark requests that belong to the smoke workflow with `# @tag smoke`.

## Commands

Run the tagged smoke requests directly:

```powershell
npx httpyac . --tag smoke --config httpyac.config.json
```

Start the MongoDB-backed server and run the tagged smoke requests:

```powershell
pwsh -File ../../run.user.ps1 -Smoke
```

The smoke requests cover health, Patient create/read, and `_lastUpdated` searches. Other `.rest` files can remain in this folder for broader user testing without being included in the smoke run.
