module.exports = {
  request: {
    https: {
      rejectUnauthorized: false
    }
  },
    "output": "pretty"
};