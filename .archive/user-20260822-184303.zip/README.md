# Local fork workspace

This folder is the fork-local working surface for this repository. It exists to capture repo context, task tracking, validation notes, and planning artifacts without modifying the shared repository guidance files.

## Purpose

- keep fork-specific working conventions in one place
- preserve task and plan artifacts used during development
- make the workflow easy for agent-assisted work without changing upstream instructions
- keep validation and testing artifacts close to the code they support

## Structure

- .user/context/ — repo and workflow context
- .user/norms/ — conventions, task and plan patterns, validation expectations
- .user/tasks/ — scoped work items such as T-0001
- .user/plans/ — multi-step or deferred work such as P-0001
- .user/rest/ — REST validation requests and sample payloads

## Working rules

- Do not update repo-global agent files like AGENTS.md or .github/copilot-instructions.md unless the upstream repo itself intentionally requires it.
- Prefer small, focused tasks with explicit success criteria.
- Record validation evidence when a fix or behavior change is completed.
- Keep plan files separate from task files when the work is broader than a single implementation.

## Intended evolution

This local structure is designed to be a stable starting point for eventual promotion into formal skills or agent workflows.
