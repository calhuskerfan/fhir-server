# Local workflow norms

This document defines the fork-local operating conventions for work in this repository.

## 1. Task files

Use task files named like T-0001, T-0002, and so on.

Task files should include:

- objective and role
- relevant entry points and references
- implementation steps
- success criteria
- notes and constraints

These files should remain focused on a single concrete problem or feature.

## 2. Plan files

Use plan files named like P-0001, P-0002, and so on when the work is broader than a single task or requires a staged approach.

Plan files should include:

- goal and scope
- work phases or milestones
- open questions and risks
- validation strategy
- deferred work versus in-flight work

A plan file should capture the bigger picture while tasks remain the execution unit.

## 3. Validation norms

- run the smallest relevant test command that checks the behavior
- record actual outcome, including pass/fail and the command used
- prefer targeted regression tests over broad suites when a fix is narrow
- keep REST validation files in .user/rest for integration checks

## 4. Scope discipline

- keep tasks tightly scoped to the root problem
- avoid unrelated UI, cleanup, or speculative work
- if a broader issue is discovered, capture it in a plan or note instead of expanding the task without direction

## 5. Local-only guidance

These files are intentionally kept under .user so they remain available to local automation and agent work without modifying upstream repository instructions.

This lets the fork evolve its own documented operating model while preserving the canonical repo files.

## 6. Future migration path

As the workflow matures, the conventions in this directory can be promoted into formal skills or agent instructions without breaking the repo’s shared defaults.
