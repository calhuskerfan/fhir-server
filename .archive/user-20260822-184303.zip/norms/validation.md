# Local validation norms

Use the smallest relevant validation command for the behavior under change.

## Targeted unit validation

For MongoDB search builder changes, prefer a narrow test filter such as:

```powershell
dotnet test "src/Microsoft.Health.Fhir.MongoDb.UnitTests/Microsoft.Health.Fhir.MongoDb.UnitTests.csproj" --filter <TestName> -v minimal
```

Examples:

```powershell
dotnet test "src/Microsoft.Health.Fhir.MongoDb.UnitTests/Microsoft.Health.Fhir.MongoDb.UnitTests.csproj" --filter VisitSearchParameter_WithLastUpdated_UsesResourceLastModifiedField -v minimal
```

## Local server validation

If a local MongoDB-backed FHIR server is running, use a focused REST file under [.user/rest](../rest) to exercise end-to-end behavior.

Example runner:

```powershell
dotnet run -c debug --launch-profile MongoDb --framework net9.0
```

## Evidence standard

A task is not considered complete without one of these:

- passing test output from the relevant command, or
- a valid REST validation result from a running local server

Record the actual command and outcome in the task or notes file.

## Scope rule

Do not broaden validation into unrelated repos or services when the behavior under test is already isolated.
