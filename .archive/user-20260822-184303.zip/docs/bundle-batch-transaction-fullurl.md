# Batch vs Transaction Bundles: `fullUrl` Semantics

## Finding

FHIR has a definitive distinction between `batch` and `transaction` bundles:

- **Batch:** Entries are independent. A failure in one entry should not change the success, failure, or resulting content of another entry. References from one batch entry to another resource being created in the same batch are explicitly non-conformant.
- **Transaction:** Entries succeed or fail as one atomic operation. The server resolves references to resources created in the same bundle, assigns server IDs, and updates matching references and links from the submitted `fullUrl` values.

`fullUrl` is meaningful in both bundle types as the identity of an entry resource. However, clients cannot rely on `fullUrl` in a batch to create dependencies between entries. The transaction-specific ID assignment and intra-bundle reference rewriting are the behaviors relevant to the distinction observed in this repository.

## FHIR Specification

- [Bundle: Resolving references in Bundles](https://build.fhir.org/bundle.html#bundle-unique) defines matching URNs and absolute or relative references against `Bundle.entry.fullUrl`.
- [Batch Processing Rules](https://build.fhir.org/http.html#transaction) require batch entries to be independent and state that references to resources created within the same batch are non-conformant.
- [Transaction Processing Rules](https://build.fhir.org/http.html#transaction) require atomic processing and require references to newly created resources to be updated with assigned IDs.
- [Replacing hyperlinks and full-urls](https://build.fhir.org/http.html#transaction) requires matching links, references, URI/URL values, UUIDs, and relevant narrative links to be replaced when identities are remapped.

The linked pages are the FHIR CI build. The HTTP page is marked Normative; the Bundle resource is normative from FHIR R4 onward. The repository supports multiple FHIR versions, so the applicable release-specific page should be checked when validating version-specific behavior.

## Repository Implementation

The distinction is implemented in the FHIR/API processing layers, before storage operations:

- [BundleHandler.cs](../../src/Microsoft.Health.Fhir.Shared.Api/Features/Resources/Bundle/BundleHandler.cs#L600-L640) populates the `fullUrl` to generated-ID dictionary and resolves references only when `_bundleType == BundleType.Transaction`.
- [BundleHandler.cs](../../src/Microsoft.Health.Fhir.Shared.Api/Features/Resources/Bundle/BundleHandler.cs#L235-L275) routes batch and transaction bundles through different processing flows; transaction bundles run `TransactionBundleValidator` and transaction execution, while batch bundles process entries independently.
- [TransactionBundleValidator.cs](../../src/Microsoft.Health.Fhir.Shared.Api/Features/Resources/Bundle/TransactionBundleValidator.cs#L83-L126) uses POST `fullUrl` values when validating transaction identities and records conditional-reference resolutions for later matching.
- [CreateResourceHandler.cs](../../src/Microsoft.Health.Fhir.Shared.Core/Features/Resources/Create/CreateResourceHandler.cs#L54-L78) preserves a generated transaction ID when the bundle context supplies one; otherwise, POST processing clears the resource ID before storage.

The storage layer receives the resulting resource operation through `FhirDataStore.UpsertAsync`; it does not decide batch versus transaction `fullUrl` semantics.

## Conclusion

The repository behavior is aligned with the core batch/transaction distinction: batch `fullUrl` values are accepted as entry identity data, but batch entries are not treated as an interdependent graph. Transaction bundles receive the additional ID mapping, reference resolution, and atomic processing behavior required for cross-entry relationships.
