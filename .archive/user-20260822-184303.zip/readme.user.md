# Chris's Companion to MS FHIR Server

## Organization

There are two primary folders that are holding information as i work through this project.  The primary driver is to be able to sync easily with the github repo.  The downside is this causes a little more overhead
1. This folder which is the microsoft fhir server forked into [this repo](https://github.com/calhuskerfan/fhir-server).  This contains information to build, run, and test the pplication
1. repo and a folder (shortcut adjoining this document).  Go there to see:
    1. supporting information, links, etc.
    1. some testing artifacts.
    1. instructions on running containers, that stuff should probably get moved to this document at some point

## Running

The primary focus of this fork is adding a MongoDb datastore to the microsoft FHIR project.

Start Mongo

```ps
docker run `
    --name fhir_mongo `
    -p 27017:27017/tcp `
    -e MONGO_INITDB_ROOT_USERNAME=admin `
    -e MONGO_INITDB_ROOT_PASSWORD=iwas@@04 `
    -d mongo:latest
```

## Start FHIR Server

```ps1

# from the root execute 'run-fhir4.user.ps1'
# to run with sql server .\run-fhir4.user.ps1 -launchProfile SqlServerContainer -containername fhir_sql

#or

dotnet run `
    -c debug `
    --launch-profile MongoDb `
    --framework net9.0
```

## Phase One

Goal is 'per resource' interaction.
    1. I.e. Patient GET/POST/PUT/DELETE, etc.
    1. Single Resource Search
    1. Batch POST

## TODO List

- Wildcard Search Implementation
- Resource Update and History
- Implement Resource Delete
- context.WithFieldNameOverride as implemented in Cosmos and look at it in terms of the 'TokenCode' and 'TokenSystem' work around in Visit String
- Review NotExpression notExpression expressions
- handle expression.IgnoreCase in VisitString
- follow up on removal of GenerateReindexSql from IQueryBuilder
- do we need to implment 'SqlExportOrchestratorJob' for Mongo
- verify ValueSets.SearchParamType Handling in SearchIndexEntryBsonDocumentGenerator
